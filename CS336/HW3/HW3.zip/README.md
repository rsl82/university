1. I get a Random Students name using random name generator and put them into CSV file.
2. With using excel functions, I generated random variables for major, minor, id, grades.
3. I made a classes from 'A' to 'Z' to test using same strategy. 
4. With the code that I attached as classeditor.py, I generated random data for hastaken. 
5. Put the csv file into database using import function in MySQL.
6. Assigned random campus for each department with using the query. (You can find it at the end of the MySQL code.)
7. All functions in the application were working well.