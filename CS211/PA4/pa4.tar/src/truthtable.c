#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>

typedef enum {AND, OR, NAND, NOR, XOR, NOT, PASS, DECODER, MULTIPLEXER } kind_t;
int counter=0;


struct gate {
kind_t kind;
int size;
struct flowNode* params;
struct gate* next;
};

struct flowNode
{
	int ind;
	struct flowNode *next;
};

struct Node {
	char name[17]; //original name
	int number; //just a number
	int value; //boolean value
	struct Node *next;
};

void insert(struct Node** head,char* Name)
{
	struct Node* newnode= (struct Node*)malloc(sizeof(struct Node));
	newnode->number=counter;
	counter++;
	strncpy(newnode->name,Name,16);
	newnode->value=99;
	newnode->next=NULL;

	if(strcmp(Name,"0")==0) newnode->value=0;
	else if(strcmp(Name,"1")==0) newnode->value=1;

	
	if((*head)==NULL)
	{
		(*head)=newnode;
	}
	else
	{
		struct Node* last=(*head);
		while(last->next != NULL)
		{
			last=last->next;
		}
		
		last->next=newnode;
	}
	
}

void gateins(struct gate** head, kind_t kind,int size)
{
	struct gate* newgate=malloc(sizeof(struct gate));
	newgate->kind=kind;
	newgate->size=size;
	newgate->params=NULL;
	newgate->next=NULL;
	
	if((*head)==NULL)
	{
		(*head)=newgate;
	}
	else
	{
		struct gate* last=(*head);
		while(last->next != NULL)
		{
			last=last->next;
		}
		
		last->next=newgate;
	}
}

void indins(struct gate** head,int ind)
{
	struct gate* temp=(*head);
	while(temp->next!=NULL)
		temp=temp->next;
	
	struct flowNode* newflow=malloc(sizeof(struct flowNode));
	newflow->ind=ind;
	newflow->next=NULL;

	if(temp->params == NULL)
		temp->params=newflow;
	else
	{
		struct flowNode* tmp_param=temp->params;
		while(tmp_param->next != NULL)
			tmp_param=tmp_param->next;
		
		tmp_param->next=newflow;
	}

}

int search(struct Node** head, char* Name)
{
	int index=0;
	struct Node *cur=(*head);
	
	while(cur!=NULL && strcmp(cur->name,Name)!=0)
	{
		index++;
		cur=cur->next;
		
	}
	
	if(cur==NULL)
		insert(head,Name);

	return index;
}



void freeList(struct Node* head)
{
	struct Node* tmp;
	
	while(head !=NULL)
	{
		tmp=head;
		head=head->next;
		free(tmp);
	}
}

void freegate(struct gate* head)
{
	struct gate* tmp;
	struct flowNode* tmp2;
	
	while(head !=NULL)
	{
		tmp=head;
		
		head=head->next;
		while(tmp->params !=NULL)
		{
			tmp2=tmp->params;
			tmp->params=tmp->params->next;
			free(tmp2);
			
		}
		free(tmp);
	}
}

void notgate(struct gate* target, struct Node* var)
{
	int x=target->params->ind;
	int y=target->params->next->ind;

	struct Node* cur=var;

	for(int i =0;i<x;i++)
		cur=cur->next;

	int val=cur->value;
	if(val==1) val=0;
	else if(val==0) val=1;
	
	cur=var;

	for(int i=0;i<y;i++)
		cur=cur->next;
	
	cur->value=val;
	
}

void passgate(struct gate* target, struct Node* var)
{
	int x=target->params->ind;
	int y=target->params->next->ind;

	struct Node* cur=var;

	for(int i =0;i<x;i++)
		cur=cur->next;

	int val=cur->value;
	if(val==1) val=1;
	else if(val==0) val=0;
	
	cur=var;

	for(int i=0;i<y;i++)
		cur=cur->next;
	
	cur->value=val;
	
}

void andgate(struct gate* target, struct Node* var)
{
	int x = target->params->ind;
	int y = target->params->next->ind;
	int z = target->params->next->next->ind;

	struct Node* cur=var;
		
	for(int i =0;i<x;i++)
		cur=cur->next;

	int val1=cur->value;
	
	cur=var;


	for(int i =0;i<y;i++)
		cur=cur->next;

	int val2=cur->value;

	if(val1==1 && val2 == 1) val1=1;
	else val1=0;

	cur=var;

	for(int i=0;i<z;i++)
		cur=cur->next;
	
	cur->value=val1;
	
}

void orgate(struct gate* target, struct Node* var)
{
	int x = target->params->ind;
	int y = target->params->next->ind;
	int z = target->params->next->next->ind;

	struct Node* cur=var;
		
	for(int i =0;i<x;i++)
		cur=cur->next;

	int val1=cur->value;
	
	cur=var;


	for(int i =0;i<y;i++)
		cur=cur->next;

	int val2=cur->value;

	if(val1==0 && val2 == 0) val1=0;
	else val1=1;

	cur=var;

	for(int i=0;i<z;i++)
		cur=cur->next;
	
	cur->value=val1;
}

void nandgate(struct gate* target, struct Node* var)
{
	int x = target->params->ind;
	int y = target->params->next->ind;
	int z = target->params->next->next->ind;

	struct Node* cur=var;
		
	for(int i =0;i<x;i++)
		cur=cur->next;

	int val1=cur->value;
	
	cur=var;


	for(int i =0;i<y;i++)
		cur=cur->next;

	int val2=cur->value;

	if(val1==1 && val2 == 1) val1=0;
	else val1=1;

	cur=var;

	for(int i=0;i<z;i++)
		cur=cur->next;
	
	cur->value=val1;
}

void norgate(struct gate* target, struct Node* var)
{
	int x = target->params->ind;
	int y = target->params->next->ind;
	int z = target->params->next->next->ind;

	struct Node* cur=var;
		
	for(int i =0;i<x;i++)
		cur=cur->next;

	int val1=cur->value;
	
	cur=var;


	for(int i =0;i<y;i++)
		cur=cur->next;

	int val2=cur->value;

	if(val1==0 && val2 == 0) val1=1;
	else val1=0;

	cur=var;

	for(int i=0;i<z;i++)
		cur=cur->next;
	
	cur->value=val1;
}

void xorgate(struct gate* target, struct Node* var)
{
	int x = target->params->ind;
	int y = target->params->next->ind;
	int z = target->params->next->next->ind;

	struct Node* cur=var;
		
	for(int i =0;i<x;i++)
		cur=cur->next;

	int val1=cur->value;
	
	cur=var;


	for(int i =0;i<y;i++)
		cur=cur->next;

	int val2=cur->value;

	if(val1==val2) val1=0;
	else val1=1;

	cur=var;

	for(int i=0;i<z;i++)
		cur=cur->next;
	
	cur->value=val1;
}

void decgate(struct gate* target, struct Node* var)
{
	int numbers=target->size;
	int value=0;
	int n=numbers-1;
	struct flowNode* par=target->params;
	struct Node* cur=var;
	for(int i =0;i<numbers;i++)
	{
		int x=par->ind;
		
		cur=var;
		
		for(int i =0;i<x;i++)
			cur=cur->next;
		
		value=value+(cur->value)*(1<<n);
		n--;

		par=par->next;
	}
	int counter=0;
	for(int i = 0; i<(1<<numbers);i++)
	{
		cur=var;
		
		int x=par->ind;
		for(int i =0;i<x;i++)
			cur=cur->next;
		
		if(counter==value)
			cur->value=1;
		else cur->value=0;

		par=par->next;
		counter++;
	}
}

void multgate(struct gate* target, struct Node* var)
{
	int numbers=target->size;
	struct flowNode* par1=target->params;
	struct flowNode* par2=target->params;
	int n = numbers-1;
	int value = 0;
	struct Node* cur=var;

	for(int i=0;i<(1<<numbers);i++)
	{
		par2=par2->next;
	}

	for(int i =0;i<numbers;i++)
	{
		int x=par2->ind;
		
		cur=var;
		
		for(int i =0;i<x;i++)
			cur=cur->next;
		
		value=value+(cur->value)*(1<<n);
		n--;

		par2=par2->next;
	}
	
	for(int i=0;i<value;i++)
	{
		par1=par1->next;
	}
	
	int y=par1->ind;
	
	cur=var;
	
	for(int i=0;i<y;i++)
		cur=cur->next;
	
	int v=cur->value;

	cur=var;
	
	y=par2->ind;
	
	for(int i=0;i<y;i++)
		cur=cur->next;
	
	cur->value=v;
	
}

int main(int argc, char **argv)
{

	if(argc!=2)
	{
	
		printf("Invalid Input");
		exit(EXIT_FAILURE);	
	}

	FILE *fp = fopen(argv[1], "r");
	if (fp==NULL)
	{
		exit(EXIT_FAILURE);
	}
	
	char* str=malloc(17);
	int temp;
	
	fscanf(fp," %16s %d",str,&temp);
	
	int inputnumber=temp;
	

	struct Node* inputNode=NULL;
	for(int i=0;i<temp;i++)
	{
		fscanf(fp," %16s",str);
		insert(&inputNode,str);
		
	}
	
	fscanf(fp," %16s %d",str,&temp);

	int outputnumber=temp;
	for(int i=0;i<temp;i++)
	{
		fscanf(fp," %16s",str);
		insert(&inputNode,str);	
	}

	struct gate* flow=NULL;
	
	while(1)
	{
		int x =fscanf(fp," %16s",str);
	
		if(x == EOF) break;
		
		
		if(strcmp(str,"NOT")==0)
		{
			
			gateins(&flow,5,0);
			
			for(int i=0;i<2;i++)
			{
			fscanf(fp," %16s",str);
			
			indins(&flow,search(&inputNode,str));
			}		
		}

		else if(strcmp(str,"AND")==0)
		{
			gateins(&flow,0,0);

			for(int i=0;i<3;i++)
			{
				fscanf(fp," %16s",str);
				indins(&flow,search(&inputNode,str));
			}
		}

		else if(strcmp(str,"OR")==0)
		{
			gateins(&flow,1,0);

			for(int i=0;i<3;i++)
			{
				fscanf(fp," %16s",str);
				indins(&flow,search(&inputNode,str));
			}
		}

		else if(strcmp(str,"NAND")==0)
		{
			gateins(&flow,2,0);

			for(int i=0;i<3;i++)
			{
				fscanf(fp," %16s",str);
				indins(&flow,search(&inputNode,str));
			}
		}

		else if(strcmp(str,"NOR")==0)
		{
			gateins(&flow,3,0);

			for(int i=0;i<3;i++)
			{
				fscanf(fp," %16s",str);
				indins(&flow,search(&inputNode,str));
			}
		}

		else if(strcmp(str,"XOR")==0)
		{
			gateins(&flow,4,0);

			for(int i=0;i<3;i++)
			{
				fscanf(fp," %16s",str);
				indins(&flow,search(&inputNode,str));
			}
		}

		else if(strcmp(str,"PASS")==0)
		{
			gateins(&flow,6,0);

			for(int i=0;i<2;i++)
			{
				fscanf(fp," %16s",str);
				indins(&flow,search(&inputNode,str));
			}
		}

		else if(strcmp(str,"DECODER")==0)
		{
			int x=0;
			fscanf(fp," %d",&x);
			gateins(&flow,7,x);

			for(int i=0;i<x;i++)
			{
				fscanf(fp," %16s",str);
				indins(&flow,search(&inputNode,str));
			}
			x=1<<x;
			
			for(int i=0;i<x;i++)
			{
				fscanf(fp," %16s",str);
				indins(&flow,search(&inputNode,str));
			}
		}
		
		else if(strcmp(str,"MULTIPLEXER")==0)
		{
			int x=0;
			fscanf(fp," %d",&x);
			gateins(&flow,8,x);

			int y=1<<x;
			
			for(int i=0;i<y;i++)
			{
				fscanf(fp, " %16s",str);
				indins(&flow,search(&inputNode,str));

				//will change it to contain value
			}

			for(int i=0;i<x+1;i++)
			{
				fscanf(fp," %16s",str);
				indins(&flow,search(&inputNode,str));
			}
		}

	}
	
	/*
	struct gate* tmpgate=flow;
	while(tmpgate!=NULL)
	{
		printf("%d ",tmpgate->kind);
		
		struct flowNode* tmpflow=tmpgate->params;
		
			while(tmpflow!=NULL)
			{
				printf("%d ",tmpflow->ind);
				tmpflow=tmpflow->next;
			}
		tmpgate=tmpgate->next;
		printf("\n");
		
	}
	*/

	int inputValues=1<<inputnumber;
	
	for(int i=0;i<inputValues;i++)
	{
		struct gate* flowpt=flow;
		int value=i;
		for(int k=inputnumber-1;k>=0;k--)
		{
			struct Node* tempNode=inputNode;
			for(int j=0;j<k;j++)
			{
				tempNode=tempNode->next;
			}
			
			tempNode->value=value%2;
			
			value=value/2;
		}

		while(flowpt!=NULL)
		{
			if(flowpt->kind==5)
				notgate(flowpt,inputNode);
			else if(flowpt->kind==0)
				andgate(flowpt,inputNode);
			else if(flowpt->kind==1)
				orgate(flowpt,inputNode);
			else if(flowpt->kind==2)
				nandgate(flowpt,inputNode);
			else if(flowpt->kind==3)
				norgate(flowpt,inputNode);
			else if(flowpt->kind==4)
				xorgate(flowpt,inputNode);
			else if(flowpt->kind==6)
				passgate(flowpt,inputNode);
			else if(flowpt->kind==7)
				decgate(flowpt,inputNode);
			else if(flowpt->kind==8)
				multgate(flowpt,inputNode);




			flowpt=flowpt->next;
		}
		

		//printing part
		
		struct Node* tempNode=inputNode;
		for(int k=0;k<inputnumber;k++)
		{
			
			printf("%d ",tempNode->value);

			tempNode=tempNode->next;
		}
		printf("|");
		
		for(int k=0;k<outputnumber;k++)
		{
			printf(" %d",tempNode->value);
			tempNode=tempNode->next;
		}

		printf("\n");
		


		
	}
		
	
	freegate(flow);
	freeList(inputNode);
	free(str);
	
	exit(EXIT_SUCCESS);
}
