#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>

struct item
{
    int weight;
    int value;
    char* name;
};

struct bag
{
    int weight;
    int value;
    int count;
};

void knapsack(int limit, int number, struct item* items)
{
    struct bag* bags  = malloc((limit+1) * (number+1) * sizeof(struct bag));
    
    
    if(bags==NULL)
    {
        printf("Memory Error\n");
        exit(EXIT_SUCCESS);
    }

    char** names= calloc((number+1)*(limit+1)*(number),sizeof(char*));
    int b=(number+1)*(limit+1)*(number);
    for(int i=0;i<b;i++)
        names[i]=calloc(32,sizeof(char));


    for(int j=0;j<=limit;j++)
    {
        for(int i=0;i<=number;i++)
        {
            if(i==0 || j==0)
            {
                (bags+i*limit+j)->value=0;
                (bags+i*limit+j)->count=0;
                (bags+i*limit+j)->weight=0;
            }
            
            else if(items[i-1].weight <= j)
            {   

	 	if( (bags+(i-1)*limit+(j-items[i-1].weight))->value + items[i-1].value > (bags+(i-1)*limit+j)->value )
                {
		    if((bags+(i-1)*limit+(j-items[i-1].weight))->weight+items[i-1].weight <=limit)
			{
                    (bags+i*limit+j)->value = (bags+(i-1)*limit+(j-items[i-1].weight))->value + items[i-1].value;
                    (bags+i*limit+j)->weight = (bags+(i-1)*limit+(j-items[i-1].weight))->weight + items[i-1].weight;
                    (bags+i*limit+j)->count = (bags+(i-1)*limit+(j-items[i-1].weight))->count + 1;

                    //string

                    for(int k=0;k<((bags+i*limit+j)->count -1);k++)
                        strcpy(*(names+i*limit*number+j*number+k),*(names+(i-1)*limit*number+(j-items[i-1].weight)*number+k));
                    int a=((bags+i*limit+j)->count) -1;
                    strcpy(*(names+i*limit*number+j*number+a),(items+i-1)->name);
			}
			else
			{
				(bags+i*limit+j)->value = (bags+(i-1)*limit+j)->value;
                    (bags+i*limit+j)->weight = (bags+(i-1)*limit+j)->weight;
                    (bags+i*limit+j)->count = (bags+(i-1)*limit+j)->count;

                    for(int k=0;k<(bags+i*limit+j)->count;k++)
                        strcpy(*(names+i*limit*number+j*number+k),*(names+(i-1)*limit*number+j*number+k));
			}

                }
                else
                {
                    (bags+i*limit+j)->value = (bags+(i-1)*limit+j)->value;
                    (bags+i*limit+j)->weight = (bags+(i-1)*limit+j)->weight;
                    (bags+i*limit+j)->count = (bags+(i-1)*limit+j)->count;

                    for(int k=0;k<(bags+i*limit+j)->count;k++)
                        strcpy(*(names+i*limit*number+j*number+k),*(names+(i-1)*limit*number+j*number+k));

                }

               
               
            }
            else
            {
                (bags+i*limit+j)->value = (bags+(i-1)*limit+j)->value;
                (bags+i*limit+j)->weight = (bags+(i-1)*limit+j)->weight;
                (bags+i*limit+j)->count = (bags+(i-1)*limit+j)->count;
                //string

                for(int k=0;k<(bags+i*limit+j)->count;k++)
                        strcpy(*(names+i*limit*number+j*number+k),*(names+(i-1)*limit*number+j*number+k));

            }


            
        }
    }

    

	
 //print string
    for(int i=0;i<=number;i++)
    {
	if(*(names+number*limit*number+limit*number+i) == NULL || *(names+number*limit*number+limit*number+i)[0] =='\0')
			break;
               
	 printf("%s\n",*(names+number*limit*number+limit*number+i));
        	

    }
		
printf("%d / %d\n",(bags+number*limit+limit)->value, (bags+number*limit+limit)->weight);

/*
for(int i=0;i<=number;i++)
{
	for(int j=0;j<=limit;j++)
	{
		printf("%d\t",(bags+i*limit+j)->value);
	}
printf("\n");
}*/
 
    for(int l=0;l<b;l++)
        free(names[l]);
    free(names);
 
    free(bags);
       


    

    return;
}

int main(int argc, char **argv)
{
    if(argc==1 || argc>3)
    {
        printf("argument Error\n");
        exit(EXIT_SUCCESS);
    }
      
    
    int limit = atoi(argv[1]);

    if(limit<=0)
    {
        printf("Limit less than 0");
            exit(EXIT_SUCCESS);
    }
    
    FILE *fp = fopen(argv[2], "r");

    if(fp==NULL)
    {
        printf("No file or file error\n");
        exit(EXIT_SUCCESS);
    }
        
    
    int number;
    fscanf(fp, "%d", &number);

    struct item* items = malloc(number*sizeof(struct item));
    if(items==NULL)
    {
        printf("Memory Error\n");
        exit(EXIT_SUCCESS);
    }

    for(int i=0;i<number;i++)
    {
        (*(items+i)).name=malloc(32*(sizeof(char)));
        if((*(items+i)).name==NULL)
        {
            printf("Memory Error\n");
            exit(EXIT_SUCCESS);
        }
    }

    for(int i=0;i<number;i++)
    {
        fscanf(fp,"%s %d %d",(*(items+i)).name,&((*(items+i)).weight),&((*(items+i)).value));
	if((*(items+i)).weight <=0 || (*(items+i)).value <=0 )
	{
		printf("There is a item which has non-positive value or weight.\n");
		exit(EXIT_SUCCESS);
	}
    }
   /*
    for(int i=0;i<number;i++)
    {
        printf("%s %d %d\n",(*(items+i)).name,(*(items+i)).weight,(*(items+i)).value);
    }
    */   
	

   knapsack(limit, number, items);
   

   for(int i=0;i<number;i++)
       free((*(items+i)).name);
   
    free(items);


    exit(EXIT_SUCCESS);
}


