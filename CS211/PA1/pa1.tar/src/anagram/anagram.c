#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
	if(argc==1)
		exit(EXIT_SUCCESS);

	int i,j;
	int count=2;
	

    for(i=1;i<argc;i++)
    {
        for(j=0;j<strlen(argv[i]);j++)
            count++;
    }
	char* string=malloc(sizeof(char)*count);
	if(string==NULL) exit(EXIT_SUCCESS);
	memset(string,0,(sizeof(char)*count));
	
	count=0;
	for(i=1;i<argc;i++)
	{
		for(j=0;j<strlen(argv[i]);j++)
		{
			if(isalpha(argv[i][j]))
			{
				string[count]=argv[i][j];
				count++;
			}
		}
	}
	
	int length= strlen(string);
	char temp;
	
	if(string[0]=='\0')
		exit(EXIT_SUCCESS);

	for(i=0;i<length;i++)
		string[i]=tolower(string[i]);
	
	for(i=0;i<length-1;i++)
	{
		for(j=i+1;j<length;j++)
		{
			if(string[i]>string[j])
			{
				temp=string[i];
				string[i]=string[j];
				string[j]=temp;
			}
		}
	}
	printf("%s\n",string);
	
	
	exit(EXIT_SUCCESS);
}	
