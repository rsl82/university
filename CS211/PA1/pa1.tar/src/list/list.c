#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node* next;
};

void newInput(struct Node** head_ref, int number)
{
	struct Node* newNode=malloc(sizeof(struct Node));
	struct Node* pointer;
	newNode->data=number;

	if((*head_ref)==NULL || (*head_ref) -> data > number)
	{
		newNode->next=(*head_ref);
		(*head_ref)=newNode;
	}

	else
	{
		pointer=(*head_ref);
		while(pointer->next!=NULL && pointer->next->data < number)
			pointer=pointer->next;
		
		
		newNode->next=pointer->next;
		pointer->next=newNode;
	}

	
}

void delete(struct Node** head_ref,int number)
{
	struct Node* pointer=(*head_ref);
	struct Node* prev;

	if(pointer->data==number)
	{
		(*head_ref)=pointer->next;
		free(pointer);
	}
	else
	{
		while(pointer!=NULL && pointer->data != number)
		{
				prev=pointer;
				pointer=pointer->next;	
		}
		
		prev->next=pointer->next;
		free(pointer);
	}
}

void traverse(struct Node* head_ref)
{
	int counter=0;
	struct Node* count=head_ref;

	while(count!=NULL)
	{
		counter++;
		count = count->next;		
	}
	
	printf("%d :",counter);
	count=head_ref;
	while(count!=NULL)
	{
		printf(" %d",count->data);
		count=count->next;
	}

	printf("\n");

}

int check(struct Node* checklist,int number)
{
	int checkdata;
	if(checklist==NULL)
		return 1;
	while(checklist!=NULL)
	{
		checkdata=checklist->data;
		if(checkdata==number)
			return 0;
		checklist=checklist->next;
	}
	
	return 1;
}

int main(int argc, char* argv[])
{
	char type;
	int number,exist;
	struct Node* head=NULL;
	while(1)
	{
		int x = scanf("%c %d",&type,&number);
		if(x== EOF) break;
		if(type=='i')
		{
			exist = check(head,number);
			if(exist==1)
				newInput(&head,number);
		traverse(head);
			
		}
		else if(type=='d')
		{
			exist = check(head,number);
			if(exist==0)
				delete(&head,number);

		traverse(head);
		}

		getchar();
		
	}

	while(head!=NULL)
	{
		struct Node* fp = head;
		head=head->next;
		free(fp);
	}
    

	exit(EXIT_SUCCESS);
}
