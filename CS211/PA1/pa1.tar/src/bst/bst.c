#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node* new(int num)
{
    struct Node* new=malloc(sizeof(struct Node));
    new->data=num;
    new->left=NULL;
    new->right=NULL;

    return new;
}

/* 1 if found, 0 if not found*/
int search(struct Node* root,int num)
{
    if(root==NULL)
        return 0;
    if(root->data== num)
        return 1;
    else if(root->data>num)
        return search(root->left,num);
    else
        return search(root->right,num);
}

struct Node* insert(struct Node* root,int num)
{
    

    if(root == NULL) return new(num);

    if(search(root,num)==1) return root;

        int x=root->data;
    
        if(x>num)
            root->left=insert(root->left,num);
        else
            root->right=insert(root->right,num);    

    return root;
        
}

void print(struct Node* root)
{
    if(root==NULL)
        return;
    printf("(");
    print(root->left);
    printf("%d",root->data);
    print(root->right);
    printf(")");
}

struct Node* delete(struct Node* root, int num)
{
	if(root==NULL)
		return root;
	if(num < root->data)
		root->left=delete(root->left,num);
	else if(num > root->data)
		root->right=delete(root->right,num);
	else if(num == root->data)
	{
		if(root->left==NULL)
		{
			struct Node* rightC=root->right;
			free(root);
			return rightC;
		}
		else if(root->right==NULL)
		{
			struct Node* leftC=root->left;
			free(root);
			return leftC;
		}

		struct Node* pointer=root->left;
		while(pointer->right!=NULL)
			pointer=pointer->right;

		root->data=pointer->data;
		root->left=delete(root->left,pointer->data);
	}
	
	return root;
		
}

void freeT(struct Node* root)
{
	if(root!=NULL)
	{
		freeT(root->left);
		freeT(root->right);
		free(root);
	}
}

int main(int argc, char* argv[])
{
    char type;
    int number,s;

    struct Node* root=NULL;
    while(1)
    {
        int x = scanf("%c",&type);
        
        if(x==EOF) break;
        
        if(type=='p')
        {
            print(root);
            printf("\n");
        }
        else
        {
            scanf("%d",&number);
		 s=search(root,number);
            if(type=='i')
            {
            
           
            root=insert(root,number);
            if(s==1) printf("not inserted\n");
            else printf("inserted\n");
            }
            else if(type=='s')
            {
            if(s==1) printf("present\n");
            else printf("absent\n");
            }
	
		else if(type=='d')
		{
			if(s==0) printf("absent\n");
			else
			{
				root=delete(root,number);
				printf("deleted\n");
			}
		}
        }
        
        
        getchar();
    }

	freeT(root);
    exit(EXIT_SUCCESS);
}
