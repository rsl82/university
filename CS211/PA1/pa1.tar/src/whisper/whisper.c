#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char* argv[])
{
	if(argc==1)
	{
		printf("...\n");
		exit(EXIT_SUCCESS);
	}	
	
	int i,j;

	printf("(");

	for(i =1;i<argc;i++)
	{
		if(i>=2)
			printf(" ");
		for(j=0;j<strlen(argv[i]);j++)
		{
			if(argv[i][j] == '!')
				argv[i][j] = '.';
			else
				argv[i][j]=tolower(argv[i][j]);
		}
	printf("%s",argv[i]);
	}
	
	printf(")\n");

	exit(EXIT_SUCCESS);


	

}
