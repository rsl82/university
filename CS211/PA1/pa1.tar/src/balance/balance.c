#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

struct Node
{
	char data;
	struct Node* next;
};


void push(struct Node** top, char data_now)
{
	struct Node* new = malloc(sizeof(struct Node));
	
	if(new == NULL)
	{
		printf("Error: Malloc\n");
		exit(EXIT_FAILURE);
	}

	new->next = *top;
	new->data = data_now;
	*top = new;

}


char pop(struct Node** top)
{
	char ch;
	struct Node* answer;

	if(*top == NULL)
		return '\0';
	
	answer=*top;
	ch=answer -> data;
	*top = answer -> next;
	free(answer);

	return ch;
}



int pair(char a, char b)
{
	if(a==')' && b=='(')
		return 1;
	else if(a=='}' && b=='{')
		return 1;
	else if(a==']' && b=='[')
		return 1;
	else
		return 0;
}


int main(int argc, char* argv[])
{
    if(argc==1)
	{
		printf("Error: no argument\n");
		 exit(EXIT_FAILURE);		
	}
       

    int count=2;

    int i,j;
    for(i=1;i<argc;i++)
    {
        for(j=0;j<strlen(argv[i]);j++)
            count++;
    }

    char* original = malloc(sizeof(char)*count);

    char* copy = malloc(sizeof(char)*count);
	
	if(original==NULL) 
	{
		printf("ERROR: malloc\n");
		exit(EXIT_FAILURE);
	}

	if(copy==NULL)
	{
		printf("ERROR: malloc\n");
		exit(EXIT_FAILURE);
	}
	
	memset(original,0,(sizeof(char)*count));
	memset(copy,0,(sizeof(char)*count));	
	
	strcpy(original,argv[1]);    
	for(i=2;i<argc;i++)
		strcat(original,argv[i]);
    
    int coun = 0;
    for(i=0;i<strlen(original);i++)
    {
        if(original[i]=='(' || original[i]=='{' || original[i]=='[' ||
            original[i]==')' || original[i]=='}' || original[i]==']')
        {
            copy[coun]=original[i];
            coun++;
        }
    }
	
	free(original);
	struct Node* stack = NULL;
	
	for(i=0;i<strlen(copy);i++)
	{
		if(copy[i]=='(' || copy[i] == '{' || copy[i] == '[')
		{
			push(&stack,copy[i]);
		}
		else
		{
			if(stack == NULL)
			{
				printf("%d: %c\n",i,copy[i]);
				exit(EXIT_FAILURE);
			}

			int result = pair(copy[i],stack->data);
			if(result==1)
				pop(&stack);
			else
			{
				printf("%d: %c\n",i,copy[i]);
				exit(EXIT_FAILURE);
			}			
			
		}
	}

	free(copy);
	if(stack!=NULL)
	{
		struct Node* temp;
		printf("open: ");
		do
		{
			if(stack->data=='(')
				printf(")");
			else if(stack->data=='{')
				printf("}");
			else
				printf("]");
			temp=stack;
			stack=stack->next;
			free(temp);

		}while(stack!=NULL);
		printf("\n");

		exit(EXIT_FAILURE);
	}

    exit(EXIT_SUCCESS);
}


