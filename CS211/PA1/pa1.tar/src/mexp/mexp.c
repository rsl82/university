#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char* argv[])
{
    if(argc==1)
        exit(EXIT_SUCCESS);

    FILE* fp=fopen(argv[1],"r");
    
    if(fp==NULL)
        exit(EXIT_SUCCESS);
    
    int k,i,j,exp,p,l;

    fscanf(fp,"%d",&k);
	

    int **arr = malloc(k*sizeof(int*));
    if(arr==NULL) exit(EXIT_SUCCESS);
    for(i=0;i<k;i++)
    {
        arr[i]= malloc(k*sizeof(int));
        if(arr[i]==NULL) exit(EXIT_SUCCESS);
    }

	int **multArr = malloc(k*sizeof(int*));
    if(multArr==NULL) exit(EXIT_SUCCESS);
    for(i=0;i<k;i++)
    {
        multArr[i]= malloc(k*sizeof(int));
        if(multArr[i]==NULL) exit(EXIT_SUCCESS);
    }
	int **result = malloc(k*sizeof(int*));
    if(result==NULL) exit(EXIT_SUCCESS);
    for(i=0;i<k;i++)
    {
        result[i]= malloc(k*sizeof(int));
        if(result[i]==NULL) exit(EXIT_SUCCESS);
    }


   

    for(i=0;i<k;i++)
    {
        for(j=0;j<k;j++)
	{
            fscanf(fp,"%d",&arr[i][j]);
		multArr[i][j]=arr[i][j];
	}

    }

  
    fscanf(fp,"%d",&exp);
/*
	for(i=0;i<k;i++)
	{
		for(j=0;j<k;j++) result[i][j]=0;
	}
*/
	for(p=0;p<exp-1;p++)
	{
		for(i=0;i<k;i++)
		{
			for(j=0;j<k;j++) result[i][j]=0;
		}

		for(i=0;i<k;i++)
		{
			for(j=0;j<k;j++)
			{
				for(l=0;l<k;l++)
					result[i][j]=result[i][j]+arr[i][l]*multArr[l][j];
			}
		}

		for(i=0;i<k;i++)
		{
			for(j=0;j<k;j++)
				arr[i][j]=result[i][j];
		
		}
	}

	if(exp==0)
	{
		for(i=0;i<k;i++)
		{
			for(j=0;j<k;j++)
			{
				if(i==j) result[i][j]=1;
				else result[i][j]=0;
			}
		}
	}
	if(exp==1)
	{
		for(i=0;i<k;i++)
		{
			for(j=0;j<k;j++)
					result[i][j]=arr[i][j];
			
		}
	}

    	

    for(i=0;i<k;i++)
    {
        for(j=0;j<k;j++)
	{
		if(j==0)  printf("%d",result[i][j]);
		else printf(" %d",result[i][j]);
	}
           
       
    printf("\n");
    }
    
    for(i=0;i<k;i++)
        free(arr[i]);
    free(arr);
for(i=0;i<k;i++)
        free(multArr[i]);
    free(multArr);
for(i=0;i<k;i++)
        free(result[i]);
    free(result);
    
    exit(EXIT_SUCCESS);

    
}
