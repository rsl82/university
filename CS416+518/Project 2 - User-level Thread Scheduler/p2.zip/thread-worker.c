// File:	thread-worker.c

// List all group member's name: Ryan Lee, Mario Barsoum
// username of iLab: rsl82, mwb96
// iLab Server: cp.cs.rutgers.edu

#include "thread-worker.h"

//Global counter for total context switches and 
//average turn around and response time
long tot_cntx_switches=0;
double avg_turn_time=0;
double avg_resp_time=0;
int respdivider=0;
int turndivider=0;
int period=0;

// INITAILIZE ALL YOUR OTHER VARIABLES HERE
// YOUR CODE HERE

struct TCB *schedulerTCB = NULL;
struct TCB *main_tcb = NULL;
struct TCB *currentTCB = NULL;
worker_t wtID = 2;
struct Queue *runq = NULL;
struct Queue *joinQueue = NULL;
struct Queue *mlfqrunq[4] = {NULL};
int yield=0;
bool interrupt=false;
int intervals[4]= {10,20,30,40};
struct itimerval timer;
struct sigaction sa;

/* create a new thread */
//NEED TIMER
int worker_create(worker_t * thread, pthread_attr_t * attr, 
                      void *(*function)(void*), void * arg) {

       // - create Thread Control Block (TCB)
       // - create and initialize the context of this worker thread
       // - allocate space of stack for this thread to run
       // after everything is set, push this thread into run queue and 
       // - make it ready for the execution.

       // YOUR CODE HERE
    
   
    //worker_TCB
    struct TCB * worker_tcb = (struct TCB * ) malloc(sizeof(struct TCB));
    worker_tcb -> id = wtID;
    wtID++;
    worker_tcb -> status = READY;
    worker_tcb -> priority = 0;
    worker_tcb -> t_ctxt = (struct ucontext_t * ) malloc(sizeof(struct ucontext_t));
    if (getcontext(worker_tcb -> t_ctxt) < 0) {
        perror("getcontext error");
        exit(1);
    }
    void * worker_stack = malloc(STACK_SIZE);

    if (worker_stack == NULL) {
        perror("Can't allocate worker_stack.");
        exit(1);
    }

    worker_tcb -> t_ctxt -> uc_link = NULL;
    worker_tcb -> t_ctxt -> uc_stack.ss_sp = worker_stack;
    worker_tcb -> t_ctxt -> uc_stack.ss_size = STACK_SIZE;
    worker_tcb -> t_ctxt -> uc_stack.ss_flags = 0;
 

    struct timespec *worker_arrival_time=(struct timespec*) malloc(sizeof(struct timespec));
    clock_gettime(CLOCK_REALTIME,worker_arrival_time);
    worker_tcb -> arrival_time = worker_arrival_time;
    makecontext(worker_tcb -> t_ctxt, (void *) &runTCB, 3, worker_tcb,function,arg);
    *thread = worker_tcb->id;
	//currentTCB=worker_tcb;
    
    
    //When worker_create is first invoked.
    if(schedulerTCB == NULL) {
    
    //Scheduler Context
        schedulerTCB = (struct TCB*) malloc (sizeof(struct TCB));
        schedulerTCB -> id = 0;
        schedulerTCB -> status = RUNNING;
        schedulerTCB -> priority = 0;
        ucontext_t *sched_ctxt = (struct ucontext_t*)malloc(sizeof(struct ucontext_t));
        schedulerTCB -> t_ctxt = sched_ctxt;
        getcontext(schedulerTCB->t_ctxt);
        void * sched_ctx_stack = malloc(STACK_SIZE);
        sched_ctxt -> uc_link = NULL;
        sched_ctxt -> uc_stack.ss_sp = sched_ctx_stack;
        sched_ctxt -> uc_stack.ss_size = STACK_SIZE;
        sched_ctxt -> uc_stack.ss_flags = 0;
        
        makecontext(schedulerTCB->t_ctxt, (void*)&schedule, 0);
        schedulerTCB -> quanta = 0;
        //schedulerTCB -> yield = 0;
        schedulerTCB -> value_ptr = NULL;


        #ifndef MLFQ
            runq = createQueue();
        #else
            for (int i = 0; i < 4; i++) {
                mlfqrunq[i] = createQueue();
            }
            runq = createQueue();
        #endif
        joinQueue = createQueue();
 //settimer

        memset (&sa, 0, sizeof (sa));
        sa.sa_handler = &handler;
        sigfillset(&sa.sa_mask);
        sigdelset(&sa.sa_mask,SIGPROF);
        sigaction (SIGPROF, &sa, NULL);
	
    //main context
        main_tcb = (struct TCB * ) malloc(sizeof(struct TCB));
        main_tcb -> id = 1;
        main_tcb -> status = READY;
        main_tcb -> priority = 0;
        
        main_tcb -> t_ctxt = (struct ucontext_t * ) malloc(sizeof(struct ucontext_t));
        getcontext(main_tcb->t_ctxt);
        currentTCB=main_tcb;

       
        // Create timer struct
	#ifndef MLFQ
        enqueue(runq, main_tcb);
        enqueue(runq,worker_tcb);
  	setTimer();
        //rule3
   	 #else
        enqueue(mlfqrunq[0], main_tcb);
        enqueue(mlfqrunq[0], worker_tcb);
        
        setMLFQ(10);
    	#endif
    
        
    }
    else {
    
    	
    	#ifndef MLFQ
        
        enqueue(runq,worker_tcb);
  
        
   	 #else
       
        enqueue(mlfqrunq[0], worker_tcb);
        
    
    	#endif
    	
    }
    

     
    return 0;
}




/* give CPU possession to other user-level worker threads voluntarily */
int worker_yield() {
	
	// - change worker thread's state from Running to Ready
	// - save context of this thread to its thread control block
	// - switch from thread context to scheduler context

	// YOUR CODE HERE
    
    currentTCB->status = BLOCKED;
   if(findJoin(currentTCB->id) == NULL) {

        enqueue(joinQueue, currentTCB);

}
 	tot_cntx_switches++;
 	interrupt=true;
    swapcontext(currentTCB->t_ctxt,schedulerTCB->t_ctxt);

	return 0;
}

/* terminate a thread */
void worker_exit(void *value_ptr) {
	// - de-allocate any dynamic memory created when starting this thread
      
	//printf("EXIT ID: %d\n",currentTCB->id);
	if(currentTCB->id!=1) {
	 struct timespec currentTime;
	clock_gettime(CLOCK_REALTIME,&currentTime);
	
	long elapsed = ((currentTime.tv_sec - currentTCB->arrival_time->tv_sec) * 1000 + (currentTime.tv_nsec - currentTCB->arrival_time->tv_nsec) / 1000000);
	double temp = avg_turn_time * turndivider;
	turndivider++;
	avg_turn_time = (elapsed+temp)/turndivider;
	}
    while(!(isEmpty(joinQueue))) {
        struct TCB* tcb = dequeue(joinQueue);
        tcb->status = READY;
        
        #ifndef MLFQ
        if(findTCB(tcb->id) == NULL) 
            enqueue(runq, tcb);
            //rule4
        #else
        
            enqueue(mlfqrunq[tcb->priority], tcb);
        #endif
        
	yield=0;
        

    }
    //printf("EXIT currentTCB:%d\n",currentTCB->id);
    currentTCB -> value_ptr = value_ptr;
    free(currentTCB -> t_ctxt -> uc_stack.ss_sp);
    free(currentTCB -> t_ctxt);
    currentTCB -> status = EXIT;
    tot_cntx_switches++;
    setcontext(schedulerTCB->t_ctxt);

	// YOUR CODE HERE
}


/* Wait for thread termination */
int worker_join(worker_t thread, void **value_ptr) {
	// - wait for a specific thread to terminate
	// - de-allocate any dynamic memory created by the joining thread

	// YOUR CODE HERE
	//printf("Thread: %d,current:%d\n",thread,currentTCB->id);
	/*
	#ifdef MLFQ
	for(int i=0;i<4;i++) {
	printf("LEVEL %d\n",i);
	sleep(1);
	qnode* a = mlfqrunq[i]->front;
	while(a!=NULL) {
		printf("%d ->",a->tcb->id);
	}
	printf("\n");
	}
	printf("end\n");
	#else
	qnode* a = runq->front;
	while(a!=NULL) {
		printf("%d ->",a->tcb->id);
	}
	#endif
	*/
    //printf("OHOHOHOH\n");
	
	
	
	
    tcb *joinThread = findTCB(thread);
	
     yield=thread;
    while((joinThread != NULL && currentTCB != joinThread && joinThread->status != (EXIT))) {
    	
        worker_yield();

    }

    if(value_ptr != NULL) {
        *(value_ptr) = joinThread->value_ptr;
    }

    

  
	return 0;
}

/* initialize the mutex lock */
int worker_mutex_init(worker_mutex_t *mutex, const pthread_mutexattr_t *mutexattr) {
	//- initialize data structures for this mutex

	// YOUR CODE HERE
    
    mutex->blocked_queue = createQueue();
    mutex->locking_id = 0;

	return 0;
}

/* aquire the mutex lock */
int worker_mutex_lock(worker_mutex_t *mutex) {

        // - use the built-in test-and-set atomic function to test the mutex
        // - if the mutex is acquired successfully, enter the critical section
        // - if acquiring mutex fails, push current thread into block list and
        // context switch to the scheduler thread

        // YOUR CODE HERE
        //printf("mutex %d,%d\n",mutex->locking_id,currentTCB->id);
         
      if(mutex->locking_id != 0 && mutex->locking_id != currentTCB->id) {
        while(atomic_flag_test_and_set(&(mutex->lock))) {
    	//printf("mutex:%d %d\n",mutex->locking_id,currentTCB->id);   
    		
            currentTCB->status = BLOCKED;
            
            enqueue(mutex->blocked_queue,currentTCB);
                    tot_cntx_switches++;
                    interrupt=true;
            swapcontext(currentTCB->t_ctxt,schedulerTCB->t_ctxt);
        }}
        mutex->locking_id = currentTCB->id;
       
        return 0;
}

/* release the mutex lock */
int worker_mutex_unlock(worker_mutex_t *mutex) {
	// - release mutex and make it available again. 
	// - put threads in block list to run queue 
	// so that they could compete for mutex later.

	// YOUR CODE HERE
	if(mutex->locking_id != currentTCB -> id) {
        return 1;
    }

    while(!(isEmpty(mutex->blocked_queue))) {
        struct TCB* tcb = dequeue(mutex->blocked_queue);
        tcb->status=READY;
	
        #ifndef MLFQ
        if(findTCB(tcb->id) == NULL) 
            enqueue(runq, tcb);
            //rule4
        #else
            enqueue(mlfqrunq[tcb->priority], tcb);
        #endif
    }

	atomic_flag_clear(&mutex);
	mutex->locking_id = 0;
	return 0;
}


/* destroy the mutex */
int worker_mutex_destroy(worker_mutex_t *mutex) {
	// - de-allocate dynamic memory created in worker_mutex_init
    free(mutex->blocked_queue);
	return 0;
}

/* scheduler */
static void schedule() {
	// - every time a timer interrupt occurs, your worker thread library 
	// should be contexted switched from a thread context to this 
	// schedule() function

	// - invoke scheduling algorithms according to the policy (PSJF or MLFQ)

	// if (sched == PSJF)
	//		sched_psjf();
	// else if (sched == MLFQ)
	// 		sched_mlfq();

	// YOUR CODE HERE
	
    currentTCB = schedulerTCB;
    stopTimer();
// - schedule policy
    #ifndef MLFQ
	// Choose PSJF
	    sched_psjf();
    #else
	// Choose MLFQ
	    sched_mlfq();
    #endif
}

/* Pre-emptive Shortest Job First (POLICY_PSJF) scheduling algorithm */
static void sched_psjf() {
	// - your own implementation of PSJF
	// (feel free to modify arguments and return types)
	

	// YOUR CODE HERE
	/*
	printf("runqcount:%d \n",runq->count);
	struct QNode* a = runq->front;
    while(a!=NULL) {
    	printf("%d ->",a->tcb->id);
    	a=a->next;
    }
     a = joinQueue->front;
    printf("JOIN QUEUE\n");
    while(a!=NULL) {
    	printf("%d ->",a->tcb->id);
    	a=a->next;
    }
    fflush(stdout);
    */
	if(runq->count!=0) {
	struct TCB *finder=dequeue(runq);
	//printf("finder id: %d\n",finder->id);
    if(finder->quanta != 0 || runq->count != 0) {
        struct TCB *compare;
	
        for(int i = 0 ; i<(runq->count);i++) {
            compare=dequeue(runq);
            if(finder->quanta > compare->quanta) {
            
                enqueue(runq,finder);
                finder = compare;
            }
            else {
                enqueue(runq,compare);
            }
        }
    }

	//printf("C");
	//fflush(stdout);
	if(interrupt=false)
		finder-> quanta = (finder -> quanta) + 1;
	//printf("finder: %d\n",finder->id);
	tot_cntx_switches++;
	//printf("YIELD%d\n",yield);
	if(yield!=0 && yield!=finder->id) {
		
		enqueue(joinQueue,finder);
		setcontext(schedulerTCB->t_ctxt);
	}
	currentTCB=finder;
        interrupt=false;
        setTimer();
	setcontext(finder->t_ctxt);
	}
	
	

}



/* Preemptive MLFQ scheduling algorithm */
static void sched_mlfq() {
	// - your own implementation of MLFQ
	// (feel free to modify arguments and return types)

	// YOUR CODE HERE

	int level = 0;
	period++;
	//rule 5
	if(period==50) {
	
	    for(int i=1;i<4;i++) {
	    	queue* current = mlfqrunq[i];
	    	while(!(isEmpty(current))) {
	    	enqueue(mlfqrunq[0],dequeue(current));
	    	}
	    }
	
	period = 0;
	}
    // Rule 1
    if(yield!=0) {
    	printf("%d\n",findMLFQ(yield));
    	qnode * q = joinQueue->front;

    	runq = mlfqrunq[findMLFQ(yield)];
    	struct TCB * tcb = dequeue(runq);
    	if(yield != tcb->id) {
    		enqueue(joinQueue,tcb);
		setcontext(schedulerTCB->t_ctxt);
    	}
    	
    }
    for (int i = 0; i < 4; i++) {
        if (!(isEmpty(mlfqrunq[i]))) {
            runq = mlfqrunq[i];
            level = i;
            break;
        }
    }


	//rule2
    rrScheduler(intervals[level]);
}

void rrScheduler(int i) {
    struct TCB* tcb = dequeue(runq);
    currentTCB = tcb;
    
  
    
    tot_cntx_switches++;
    setMLFQ(i);
    //printf("%d\n",tcb->id);
    setcontext(tcb->t_ctxt);
    
}

//DO NOT MODIFY THIS FUNCTION
/* Function to print global statistics. Do not modify this function.*/
void print_app_stats(void) {

       fprintf(stderr, "Total context switches %ld \n", tot_cntx_switches);
       fprintf(stderr, "Average turnaround time %lf \n", avg_turn_time);
       fprintf(stderr, "Average response time  %lf \n", avg_resp_time);
}



// Feel free to add any other functions you need

// YOUR CODE HERE
struct Queue *createQueue() {
    struct Queue *queue = (struct Queue *)malloc(sizeof(struct Queue));
    queue->front=queue->rear=NULL;
    queue->count=0;

    return queue;
}

bool isEmpty(queue *queue) {
    return queue->count == 0;
}

void enqueue(struct Queue *queue, tcb *item) {
    struct QNode * newNode = (struct QNode *) malloc(sizeof(struct QNode));
    newNode -> tcb = item;
    newNode -> next = NULL;
	
    if (isEmpty(queue)) {
            queue->front = newNode;
        }
    else {
        queue->rear->next = newNode;
    }

    queue->rear = newNode;
    queue->count++;
}

tcb *dequeue(struct Queue *queue) {
    if(isEmpty(queue)) {
        return NULL;
    }

    struct QNode *node = queue->front;
    queue->front = node->next;
    struct TCB *value = node->tcb;
    //free(node);
    queue->count--;
    return value;
}

static void handler() {
    //printf("D%d\n",currentTCB->id);
 	//perror("handle");
    if(currentTCB->id != 0 && currentTCB->status != BLOCKED) {
        #ifndef MLFQ
        if(findTCB(currentTCB->id) == NULL) 
            enqueue(runq, currentTCB);
            //rule4
        #else
            if(currentTCB->priority != 3) {
                currentTCB -> priority = (currentTCB -> priority) + 1;
            }
            enqueue(mlfqrunq[currentTCB->priority], currentTCB);
        #endif
        tot_cntx_switches++;
        swapcontext(currentTCB->t_ctxt,schedulerTCB->t_ctxt);
    }
}

static tcb *findTCB(worker_t id) {
    

        if(isEmpty(runq)) {
            //perror("queue is empty");
            return NULL;
        }
        struct QNode* a = runq->front;
    
    	for(int i=0;i<runq->count;i++) {
	    	if(a->tcb->id == id) {
	    	    return a->tcb;
	    	}
	    	a = a->next;
    	}


    

    //perror("No thread with that ID");
    return NULL;
}

tcb *findJoin(worker_t id) {
	if(isEmpty(joinQueue)) {
            //perror("queue is empty");
            return NULL;
        }
        struct QNode* a = joinQueue->front;
    
    	for(int i=0;i<joinQueue->count;i++) {
	    	if(a->tcb->id == id) {
	    	    return a->tcb;
	    	}
	    	a = a->next;
    	}


    

    //perror("No thread with that ID");
    return NULL;
}


int findMLFQ(worker_t id) {
	struct QNode *queue;
        for(int i=0;i<4;i++) {
            if(isEmpty(mlfqrunq[i])) {
                continue;
            }
            queue = mlfqrunq[i]->front;
            while(queue==NULL || queue->tcb->id == id) {
            	if(queue->tcb->id == id) {
            		return i;
            	}
            	queue= queue->next;
            }
        }
    return -1;

}

void runTCB(tcb* tcb, void *(*function)(void*), void * arg) {
	struct timespec currentTime;
	clock_gettime(CLOCK_REALTIME,&currentTime);
	
	long elapsed = ((currentTime.tv_sec - currentTCB->arrival_time->tv_sec) * 1000 + (currentTime.tv_nsec - currentTCB->arrival_time->tv_nsec) / 1000000);
	double temp = avg_resp_time * respdivider;
	respdivider++;
	avg_resp_time = (elapsed+temp)/respdivider;
    void* value = (*function)(arg);
    currentTCB -> status = EXIT;
    

}

void setMLFQ(int i) {
	timer.it_interval.tv_usec = i * 10000;
        timer.it_interval.tv_sec = 0;
        timer.it_value.tv_usec = i * 10000;
        timer.it_value.tv_sec = 0;


        // Set the timer up (start the timer)
        setitimer(ITIMER_PROF, &timer, NULL);
}
void setTimer() {
	
	timer.it_interval.tv_usec = INTERVAL * 10000;
        timer.it_interval.tv_sec = 0;
        timer.it_value.tv_usec = INTERVAL * 10000;
        timer.it_value.tv_sec = 0;


        // Set the timer up (start the timer)
        setitimer(ITIMER_PROF, &timer, NULL);
}
void stopTimer() {
timer.it_interval.tv_usec = 0;
        timer.it_interval.tv_sec = 0;
        timer.it_value.tv_usec = 0;
        timer.it_value.tv_sec = 0;


        // Set the timer up (start the timer)
        setitimer(ITIMER_PROF, &timer, NULL);
}
